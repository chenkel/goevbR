library(testit)
test_pkg('leaflet')
