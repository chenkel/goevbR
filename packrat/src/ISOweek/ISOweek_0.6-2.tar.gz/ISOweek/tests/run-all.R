library(testthat)
library(ISOweek)

test_package("ISOweek")